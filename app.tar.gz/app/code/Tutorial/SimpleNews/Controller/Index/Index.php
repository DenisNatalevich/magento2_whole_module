<?php
namespace Tutorial\SimpleNews\Controller\Index;

//use Tutorial\SimpleNews\Controller\News;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\View\Result\PageFactory;
use Tutorial\SimpleNews\Helper\Data;
use Tutorial\SimpleNews\Controller\News;
use Tutorial\SimpleNews\Model\NewsFactory;

class Index extends News 
{
    public function execute()
    {
        //echo $this->_dataHelper->getHeadTitle(), '<br/>' ;
        //echo __METHOD__;
        $pageFactory = $this->_pageFactory->create();
        $pageFactory->getConfig()->getTitle()->set($this->_dataHelper->getHeadTitle());
        $breadcrumbs = $pageFactory->getLayout()->getBlock('breadcrumbs');
        $breadcrumbs->addCrumb('home', ['label'=>__('Home'), 'title'=>__("Home"), 'link'=>$this->_url->getUrl('')]);
        $breadcrumbs->addCrumb('simplenews', ['label'=>__('Simple News'), 'title' => __('Simple News')]);

        return $pageFactory;
    }
}
