<?php
namespace Tutorial\SimpleNews\Controller\Adminhtml\News;

use Tutorial\SimleNews\Controller\Adminhtml\News;

class Grid extends News {
    public function execute() {
        return $this->_resultPageFactory->create();
    }
}
