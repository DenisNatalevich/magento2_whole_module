<?php
namespace Tutorial\SimpleNews\Block\Lastest;

use Tutorial\SimpleNews\Block\Lastest;
use Tutorial\SimpleNews\Model\System\Config\LastestNews\Position;

class Right extends Lastest {
    public function _construct() {
        $position = $this->_dataHelper->getLastestNewsBlockPosition() ;

        if($position == Position::RIGHT) {
            $this->setTemplate('Tutorial_SimpleNews::lastest.phtml');
        }
    }
}
