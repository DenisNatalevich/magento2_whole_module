<?php
namespace Tutorial\SimpleNews\Block;

use Magento\Framework\View\Element\Template;
use Tutorial\SimpleNews\Helper\Data;
use Tutorial\SimpleNews\Model\NewsFactory;
//use Tutorial\SimpleNews\Model\System\Config\Status;

class Lastest extends Template {
    /** @var \Tutorial\SimpleNews\Helper\Data */
    protected $_dataHelper;

    /**@var \Tutorial\SimpleNews\Model\NewsFactory */
    protected $_newsFactory;

    public function __construct(Template\Context $context, Data $dataHelper, NewsFactory $newsFactory) {
        $this->_dataHelper = $dataHelper;
        $this->_newsFactory = $newsFactory;
        parent::__construct($context);
    }

    /**
     * get five latest news
     *
     * @return \Tutorial\SimpleNews\Model\Resource\News\Collection
     */
    public function getLatestNews() {
        $collection = $this->_newsFactory->create()->getCollection();
        $collection->addFieldToFilter('status', array('eq'=>1));
        $collection->getSelect()->order('id DESC')->limit(5);

        return $collection;
    }
}
