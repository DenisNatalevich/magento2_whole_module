<?php
namespace Tutorial\SimpleNews\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\View\Result\PageFactory;
use Tutorial\SimpleNews\Helper\Data;
use Tutorial\SimpleNews\Controller\News;
use Tutorial\SimpleNews\Model\NewsFactory;

class View extends News {
    public function execute() {
        //get news Id
        $newsId = $this->getRequest()->getParam('id');

        //get news data
        $news = $this->_newsFactory->create()->load($newsId);
        
        //Save news data into the registry
        $this->_objectManager->get('Magento\Framework\Registry')->register('newsData', $news);

        $pageFactory = $this->_pageFactory->create();

        //add title
        $pageFactory->getConfig()->getTitle()->set($news->getTitle());


        //add breadcrumb
        /** @var \Magento\Theme\Block\Html\Breadcrumbs */
        $breadcrumbs = $pageFactory->getLayout()->getBlock('breadcrumbs');
        $breadcrumbs->addCrumb('home',
            ['label'=>__('Home'), 'title'=>__('Home'), 'link'=>$this->_url->getUrl('')]
        );

        $breadcrumbs->addCrumb('simplenews',
            ['label'=>__('Simple News'), 'title'=>__('Simple News'), 'link'=>$this->_url->getUrl('news')]
        );

        $breadcrumbs->addCrumb('news', 
            ['label' => $news->getTitle(), 'title' => $news->getTitle()]
        );

        return $pageFactory;
    }
}
